from django.db import models

class Empresa(models.Model):
    nome = models.CharField(max_length=150)
    cnpj = models.CharField(max_length=18, blank=True)
    cidade = models.CharField(max_length=80, blank=True)
    criado_em = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.nome

class Contato(models.Model):
    nome = models.CharField(max_length=150)
    telefone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    empresa = models.ForeignKey(Empresa, null=True, blank=True, on_delete=models.SET_NULL)
    cidade = models.CharField(max_length=80, blank=True)
    criado_em = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.nome

class Visita(models.Model):
    contato = models.ForeignKey(Contato, on_delete=models.CASCADE)
    data = models.DateField()
    assunto = models.CharField(max_length=200)
    status = models.CharField(max_length=40, default='Pendente')

class Demanda(models.Model):
    contato = models.ForeignKey(Contato, on_delete=models.CASCADE)
    titulo = models.CharField(max_length=200)
    descricao = models.TextField(blank=True)
    prioridade = models.CharField(max_length=20, default='Normal')
    status = models.CharField(max_length=20, default='Aberta')
    criado_em = models.DateTimeField(auto_now_add=True)
