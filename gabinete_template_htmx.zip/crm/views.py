from django.shortcuts import render, get_object_or_404
from .models import Contato, Visita, Demanda

def contatos_list(request):
    q = request.GET.get('q', '').strip()
    contatos = Contato.objects.all()
    if q:
        contatos = contatos.filter(nome__icontains=q)
    ctx = {'contatos': contatos, 'q': q}
    return render(request, 'contatos/list.html', ctx)

def contatos_table_partial(request):
    q = request.GET.get('q', '').strip()
    contatos = Contato.objects.all()
    if q:
        contatos = contatos.filter(nome__icontains=q)
    return render(request, 'contatos/_table.html', {'contatos': contatos})

def contatos_detail(request, pk):
    contato = get_object_or_404(Contato, pk=pk)
    return render(request, 'contatos/detail.html', {'contato': contato})

def contatos_tab_partial(request, pk, tab):
    contato = get_object_or_404(Contato, pk=pk)
    if tab == 'resumo':
        template = 'contatos/_tab_resumo.html'
        ctx = {'contato': contato}
    elif tab == 'atividades':
        template = 'contatos/_tab_atividades.html'
        atividades = Visita.objects.filter(contato=contato).order_by('-data')
        ctx = {'contato': contato, 'atividades': atividades}
    elif tab == 'anexos':
        template = 'contatos/_tab_anexos.html'
        ctx = {'contato': contato}
    else:
        template = 'contatos/_tab_resumo.html'
        ctx = {'contato': contato}
    return render(request, template, ctx)
