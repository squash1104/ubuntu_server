from django.urls import path
from . import views

app_name = 'crm'
urlpatterns = [
    path('contatos/', views.contatos_list, name='contatos_list'),
    path('contatos/partial/', views.contatos_table_partial, name='contatos_table_partial'),
    path('contatos/<int:pk>/', views.contatos_detail, name='contatos_detail'),
    path('contatos/<int:pk>/tab/<str:tab>/', views.contatos_tab_partial, name='contatos_tab_partial'),
]
