Django + HTMX — Layout estilo SuperOffice (templates prontos)

Passos:
1) Copie a pasta 'templates', a pasta 'crm' e 'static' para o seu projeto Django novo (ex.: /opt/gabinete).
2) Em gabinete/settings.py:
   - INSTALLED_APPS += ["django_htmx","crm"]
   - MIDDLEWARE += ["django_htmx.middleware.HtmxMiddleware"]
   - TEMPLATES[0]["DIRS"] = [BASE_DIR / "templates"]
   - STATIC_URL = "static/"
   - STATIC_ROOT = BASE_DIR / "staticfiles"

3) Em gabinete/urls.py:
   from django.contrib import admin
   from django.urls import path, include
   from django.views.generic import TemplateView

   urlpatterns = [
       path('admin/', admin.site.urls),
       path('', TemplateView.as_view(template_name='dashboard.html'), name='dashboard'),
       path('crm/', include('crm.urls')),
   ]

4) Migrações e runserver:
   python manage.py makemigrations && python manage.py migrate
   python manage.py runserver

Acesse: / (dashboard) e /crm/contatos/
